#!/usr/bin/env python3
"""
Backlink API credential management for Claude SEO.

Loads and validates credentials for Moz Link Explorer API,
Bing Webmaster Tools API, and Common Crawl web graphs.
Supports config file and environment variable fallbacks.

Usage:
    python backlinks_auth.py --check                  # Check all credentials
    python backlinks_auth.py --check moz              # Check specific service
    python backlinks_auth.py --check --json            # JSON output
    python backlinks_auth.py --setup                   # Show setup instructions
    python backlinks_auth.py --tier                    # Show detected credential tier
"""

import argparse
import json
import os
import subprocess
import sys
from typing import Optional

# Import SSRF protection from the canonical url_safety module.
# google_auth.validate_url is a back-compat wrapper around the same function.
_SCRIPTS_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPTS_DIR not in sys.path:
    sys.path.insert(0, _SCRIPTS_DIR)
try:
    import url_safety  # noqa: F401
except ImportError as _import_exc:
    # Hard fail: a private-IP/loopback fallback that omits SSRF checks is
    # worse than no validation at all. The previous fallback shipped in
    # v1.9.0 silently allowed private IP literals and was flagged in the
    # cybersecurity audit (v2.0.0 Phase H). Refuse to run instead.
    raise RuntimeError(
        "scripts/url_safety.py is required for SSRF protection. "
        "Install with: pip install -r requirements.txt"
    ) from _import_exc

try:
    # Reuse google_auth.py's legacy-permission remediation helper instead of
    # duplicating it. It is path/mode-generic (no dependency on google_auth's
    # own TOKEN_PATH), so it is safe to share as-is.
    from google_auth import _chmod_quiet
except ImportError as _import_exc:
    raise RuntimeError(
        "scripts/google_auth.py is required alongside backlinks_auth.py. "
        "Install with: pip install -r requirements.txt"
    ) from _import_exc

CONFIG_PATH = os.path.expanduser("~/.config/claude-seo/backlinks-api.json")
CACHE_DIR = os.path.expanduser("~/.cache/claude-seo/commoncrawl")

# Which services need which auth type
SERVICE_AUTH = {
    "moz": "api_key",
    "bing": "api_key",
    "keywordseverywhere": "api_key",
    "commoncrawl": "none",
    "verify": "none",
}

# Human-readable service names
SERVICE_NAMES = {
    "moz": "Moz Link Explorer API",
    "bing": "Bing Webmaster Tools API",
    "keywordseverywhere": "Keywords Everywhere (Open PageRank)",
    "commoncrawl": "Common Crawl Web Graph",
    "verify": "Backlink Verification Crawler",
}


def _restrict_to_current_user_windows(path: str) -> None:
    """Best-effort Windows ACL restriction to the current user (issue #290).

    POSIX mode bits (``chmod``/``fchmod``) are meaningless on Windows: NTFS
    access control is ACL-based, so forcing ``0o600`` there does not actually
    stop other local accounts from reading the file. ``icacls`` is the
    closest equivalent. Failures (missing binary, non-NTFS volume, a
    restricted shell) are swallowed with a logged warning rather than
    aborting the credential write or load; POSIX users never reach this
    function at all, since it is a no-op there.
    """
    if os.name != "nt":
        return
    user = os.environ.get("USERNAME", "").strip()
    if not user:
        print(
            f"Warning: USERNAME is not set; could not restrict {path} to the current user",
            file=sys.stderr,
        )
        return
    try:
        result = subprocess.run(
            ["icacls", path, "/inheritance:r", "/grant:r", f"{user}:F"],
            check=False,
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "").strip()
            print(
                f"Warning: icacls could not restrict {path} to {user} "
                f"(exit {result.returncode}): {detail}",
                file=sys.stderr,
            )
    except Exception as exc:  # best-effort hardening only; never fatal
        print(
            f"Warning: could not restrict {path} to the current user via icacls: {exc}",
            file=sys.stderr,
        )


def _write_secure_json(path: str, data: dict) -> None:
    """Write ``data`` to ``path`` as JSON with hardened, non-world-readable permissions.

    Mirrors ``google_auth.py``'s ``_save_oauth_token`` write pattern:
        1. Pre-chmod any existing file (closes a legacy umask=022 window).
        2. ``os.open`` with explicit mode 0o600 (applies only to newly
           created files; ignored by the OS when the file already exists).
        3. ``os.fchmod`` on the open fd to *force* 0o600 even if the file
           pre-existed at step 2; defeats the os.path.exists()/os.open()
           TOCTOU race where an external writer could install a 0o644 file
           between the two calls.
        4. On Windows, a best-effort ``icacls`` restriction, since steps 2-3
           are a no-op there (issue #290).

    The file is never world-readable, even briefly.
    """
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        _chmod_quiet(path, 0o600)
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
    fd = os.open(path, flags, 0o600)
    try:
        fchmod = getattr(os, "fchmod", None)
        if fchmod is not None:
            fchmod(fd, 0o600)
    except OSError:
        pass  # FS may not support fchmod (e.g. some Windows filesystems)
    with os.fdopen(fd, "w") as f:
        json.dump(data, f, indent=2)
    _restrict_to_current_user_windows(path)


def save_config(config: dict) -> None:
    """Persist backlink API credentials to CONFIG_PATH with hardened permissions."""
    _write_secure_json(CONFIG_PATH, config)


def load_config() -> dict:
    """
    Load configuration from config file with environment variable fallbacks.

    Reads ~/.config/claude-seo/backlinks-api.json first. Any missing fields
    are filled from environment variables.

    Returns:
        Dictionary with keys: moz_api_key, bing_api_key,
        bing_verified_sites, commoncrawl_cache_dir.
    """
    config = {
        "moz_api_key": None,
        "bing_api_key": None,
        "bing_verified_sites": [],
        "keywordseverywhere_api_key": None,
        "commoncrawl_cache_dir": CACHE_DIR,
    }

    # Load from config file
    if os.path.exists(CONFIG_PATH):
        # Remediate a world-readable legacy file in place (matches
        # google_auth._load_oauth_token), including on Windows (#290).
        _chmod_quiet(CONFIG_PATH, 0o600)
        _restrict_to_current_user_windows(CONFIG_PATH)
        try:
            with open(CONFIG_PATH, "r") as f:
                file_config = json.load(f)
            for k, v in file_config.items():
                if v is not None and v != "":
                    config[k] = v
        except (json.JSONDecodeError, IOError) as e:
            print(f"Warning: Could not read config file: {e}", file=sys.stderr)

    # Environment variable fallbacks
    if not config["moz_api_key"]:
        config["moz_api_key"] = os.environ.get("MOZ_API_KEY")

    if not config["bing_api_key"]:
        config["bing_api_key"] = os.environ.get("BING_WEBMASTER_API_KEY")

    if not config["keywordseverywhere_api_key"]:
        config["keywordseverywhere_api_key"] = os.environ.get("KEYWORDSEVERYWHERE_API_KEY")

    # Expand cache dir path
    config["commoncrawl_cache_dir"] = os.path.expanduser(
        config.get("commoncrawl_cache_dir", CACHE_DIR)
    )

    return config


def check_credentials(service: str) -> dict:
    """
    Validate credentials for a specific backlink data service.

    Args:
        service: One of 'moz', 'bing', 'commoncrawl', 'verify'.

    Returns:
        Dictionary with:
            - available: bool
            - method: auth method description
            - service: human-readable service name
            - error: error message or None
    """
    result = {
        "available": False,
        "method": SERVICE_AUTH.get(service, "unknown"),
        "service": SERVICE_NAMES.get(service, service),
        "error": None,
    }

    config = load_config()

    if service == "moz":
        api_key = config.get("moz_api_key")
        if api_key:
            result["available"] = True
            result["method"] = "api_key_configured"
            result["verified"] = False
            result["note"] = (
                "Moz credentials are configured but not live-verified by --check. "
                "Run a Moz command such as `python scripts/moz_api.py metrics "
                "example.com --json` to test quota and permissions."
            )
        else:
            result["error"] = (
                "No Moz API key found. Set MOZ_API_KEY environment variable "
                f"or add 'moz_api_key' to {CONFIG_PATH}\n"
                "         Sign up free at https://moz.com/products/api"
            )

    elif service == "bing":
        api_key = config.get("bing_api_key")
        if api_key:
            result["available"] = True
            result["method"] = "api_key_configured"
            result["verified"] = False
            sites = config.get("bing_verified_sites", [])
            if sites:
                result["verified_sites"] = sites
                result["note"] = (
                    "Bing credentials and site list are configured but not live-verified "
                    "by --check. Run a Bing Webmaster query to test access."
                )
            else:
                result["note"] = (
                    "Bing API key is configured but not live-verified. No verified "
                    "sites are listed; add 'bing_verified_sites' to config for "
                    "site-specific backlink queries."
                )
        else:
            result["error"] = (
                "No Bing Webmaster API key found. Set BING_WEBMASTER_API_KEY "
                f"environment variable or add 'bing_api_key' to {CONFIG_PATH}\n"
                "         Get free key at https://www.bing.com/webmasters"
            )

    elif service == "keywordseverywhere":
        api_key = config.get("keywordseverywhere_api_key")
        if api_key:
            result["available"] = True
            result["method"] = "api_key_configured"
            result["verified"] = False
            result["note"] = (
                "Keywords Everywhere credentials are configured but not live-verified by --check. "
                "Run `python scripts/keywordseverywhere_api.py rank example.com --json` to test."
            )
        else:
            result["error"] = (
                "No Keywords Everywhere API key found. Set KEYWORDSEVERYWHERE_API_KEY "
                f"environment variable or add 'keywordseverywhere_api_key' to {CONFIG_PATH}\n"
                "         Get a key from your Keywords Everywhere dashboard"
            )

    elif service == "commoncrawl":
        # Common Crawl is always available (public data, no auth needed)
        result["available"] = True
        result["method"] = "none (public data)"
        cache_dir = config.get("commoncrawl_cache_dir", CACHE_DIR)
        result["cache_dir"] = cache_dir
        if os.path.exists(cache_dir):
            cached_files = [f for f in os.listdir(cache_dir) if f.endswith(".json")]
            result["cached_domains"] = len(cached_files)
        else:
            result["cached_domains"] = 0

    elif service == "verify":
        # Verification crawler is always available (uses fetch_page.py + parse_html.py)
        result["available"] = True
        result["method"] = "none (local crawler)"
        # Check that required scripts exist
        fetch_script = os.path.join(_SCRIPTS_DIR, "fetch_page.py")
        parse_script = os.path.join(_SCRIPTS_DIR, "parse_html.py")
        if not os.path.exists(fetch_script):
            result["available"] = False
            result["error"] = f"Required script not found: {fetch_script}"
        elif not os.path.exists(parse_script):
            result["available"] = False
            result["error"] = f"Required script not found: {parse_script}"

    else:
        result["error"] = f"Unknown service: {service}"

    return result


def detect_tier() -> dict:
    """
    Detect the backlink credential tier available.

    Tier 0: No API keys (Common Crawl + Verification Crawler always available)
    Tier 1: Moz API key configured
    Tier 2: Moz + Bing configured
    Tier 3: All + DataForSEO MCP available (checked externally)

    Returns:
        Dictionary with tier, description, capabilities, missing.
    """
    config = load_config()

    has_moz = bool(config.get("moz_api_key"))
    has_bing = bool(config.get("bing_api_key"))
    has_kwe = bool(config.get("keywordseverywhere_api_key"))

    if has_moz and has_bing:
        return {
            "tier": 2,
            "description": "Full Free (Moz + Bing + Common Crawl + Verify)",
            "capabilities": [
                "Moz DA/PA/Spam Score (any domain)",
                "Moz referring domains and anchors",
                "Bing inbound links (verified sites)",
                "Bing comparison between registered properties",
                "Common Crawl domain-level graph",
                "Backlink verification crawler",
            ] + (["Keywords Everywhere Open PageRank (0-10 domain rank)"] if has_kwe else []),
            "missing": "Add DataForSEO extension for premium backlink data (paid)",
        }
    elif has_moz:
        return {
            "tier": 1,
            "description": "Moz Only (Moz + Common Crawl + Verify)",
            "capabilities": [
                "Moz DA/PA/Spam Score (any domain)",
                "Moz referring domains and anchors",
                "Common Crawl domain-level graph",
                "Backlink verification crawler",
            ] + (["Keywords Everywhere Open PageRank (0-10 domain rank)"] if has_kwe else []),
            "missing": (
                "Add Bing Webmaster API key for registered-property link data. "
                "Free at https://www.bing.com/webmasters"
            ),
        }
    else:
        return {
            "tier": 0,
            "description": "Basic (Common Crawl + Verify only)",
            "capabilities": [
                "Common Crawl domain-level graph (PageRank, in-degree)",
                "Backlink verification crawler",
            ] + (["Keywords Everywhere Open PageRank (0-10 domain rank)"] if has_kwe else []),
            "missing": (
                "Add Moz API key for DA/PA and spam scoring. "
                "Free at https://moz.com/products/api (2,500 rows/month). "
                "Or add a Keywords Everywhere key for a lightweight 0-10 domain rank fallback."
            ),
        }


def get_moz_api_key() -> Optional[str]:
    """Get the Moz API key from config or environment."""
    config = load_config()
    return config.get("moz_api_key")


def get_bing_api_key() -> Optional[str]:
    """Get the Bing Webmaster API key from config or environment."""
    config = load_config()
    return config.get("bing_api_key")


def get_keywordseverywhere_api_key() -> Optional[str]:
    """Get the Keywords Everywhere API key from config or environment."""
    config = load_config()
    return config.get("keywordseverywhere_api_key")


def get_bing_verified_sites() -> list:
    """Get the list of Bing-verified sites from config."""
    config = load_config()
    return config.get("bing_verified_sites", [])


def get_cache_dir() -> str:
    """Get the Common Crawl cache directory, creating it if needed."""
    config = load_config()
    cache_dir = config.get("commoncrawl_cache_dir", CACHE_DIR)
    os.makedirs(cache_dir, exist_ok=True)
    return cache_dir


def print_setup_instructions():
    """Print step-by-step setup instructions for all backlink APIs."""
    print("""
Backlink API Setup Instructions
================================

Free backlink data sources for Claude SEO. No payment required for any of these.

TIER 0: ALWAYS AVAILABLE (no setup needed)
------------------------------------------
  Common Crawl Web Graph: Public domain-level link data with PageRank.
  Backlink Verification:  Crawls pages to verify if backlinks still exist.

  These work immediately with no configuration.

TIER 1: MOZ API (free signup, 2,500 rows/month)
-------------------------------------------------
  1. Go to https://moz.com/products/api
  2. Click "Start your free 30-day trial" or "Get Free Access"
     (Free tier continues after trial with 2,500 rows/month)
  3. A valid credit card is required at signup but will NOT be charged
  4. After signup, go to https://moz.com/products/api/keys
  5. Copy your API credentials. Claude SEO accepts either:
     - a token-style key (looks like: mozscape-xxxxxxxx)
     - free-tier accessId:secret credentials, raw or base64 encoded

  Configure:
    export MOZ_API_KEY="mozscape-xxxxxxxx"
    # or: export MOZ_API_KEY="accessId:secret"

  Or save to """ + CONFIG_PATH + """:
    {
      "moz_api_key": "mozscape-xxxxxxxx"
    }

  Provides: Domain Authority, Page Authority, Spam Score, link counts,
            referring domains, anchor text distribution (any domain).
  Rate limit: 1 request per 10 seconds.
  Note: `--check moz` reports whether credentials are configured; run
        `python scripts/moz_api.py metrics example.com --json` for a live
        permission/quota test.

TIER 2: + BING WEBMASTER TOOLS API (free, verified sites)
-----------------------------------------------------------
  1. Go to https://www.bing.com/webmasters
  2. Sign in with Microsoft account
  3. Add and verify your site(s) (DNS, meta tag, or CNAME)
  4. Go to Settings > API access > API key
  5. Copy your API key

  Add to """ + CONFIG_PATH + """:
    {
      "moz_api_key": "mozscape-xxxxxxxx",
      "bing_api_key": "your-bing-api-key",
      "bing_verified_sites": ["example.com", "other-site.com"]
    }

  Or set environment variable:
    export BING_WEBMASTER_API_KEY="your-bing-api-key"

  Provides: Inbound links with anchor text, referring domains,
            competitor backlink comparison (unique feature!).
  Limitation: Only works for verified sites + their competitors.

OPTIONAL: KEYWORDS EVERYWHERE / OPEN PAGERANK (free signup, single-metric fallback)
--------------------------------------------------------------------------------------
  1. Sign in to the Keywords Everywhere dashboard (formerly OpenPageRank)
  2. Copy your API key (format: opr_live_xxxxxxxxxxxxxxxx)
  3. Verify current pricing/credit terms in the dashboard before relying on it --
     not independently confirmed here.

  Configure:
    export KEYWORDSEVERYWHERE_API_KEY="opr_live_xxxxxxxxxxxxxxxx"

  Or add to """ + CONFIG_PATH + """:
    {
      "keywordseverywhere_api_key": "opr_live_xxxxxxxxxxxxxxxx"
    }

  Provides: A single 0-10 domain rank score, up to 100 domains per request.
  No referring domains, anchors, or top pages -- use Moz for those. A
  lightweight Profile Overview fallback when Moz isn't configured.

PREMIUM: DATAFORSEO EXTENSION (paid, most comprehensive)
----------------------------------------------------------
  For full commercial-grade backlink data, install the DataForSEO extension:
    ./extensions/dataforseo/install.sh

  Provides: 35+ trillion links, real-time updates, toxic scoring,
            anchor text, competitor gap analysis, link velocity.

VERIFY CONFIGURATION:
  python scripts/backlinks_auth.py --check
  python scripts/backlinks_auth.py --tier
  `--check` is configuration-only for Moz/Bing and does not claim live
  verification unless a specific API query has been run.
""")


def main():
    parser = argparse.ArgumentParser(
        description="Backlink API credential management for Claude SEO"
    )
    parser.add_argument(
        "--check",
        nargs="?",
        const="all",
        metavar="SERVICE",
        help="Check credentials. Optionally specify: moz, bing, keywordseverywhere, commoncrawl, verify",
    )
    parser.add_argument(
        "--setup",
        action="store_true",
        help="Show setup instructions",
    )
    parser.add_argument(
        "--tier",
        action="store_true",
        help="Show detected credential tier",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output as JSON",
    )

    args = parser.parse_args()

    if args.setup:
        print_setup_instructions()
        return

    if args.tier:
        tier_info = detect_tier()
        if args.json:
            print(json.dumps(tier_info, indent=2))
        else:
            print(f"Backlink Tier: {tier_info['tier']} -- {tier_info['description']}")
            if tier_info["capabilities"]:
                print(f"Capabilities: {', '.join(tier_info['capabilities'])}")
            if tier_info["missing"]:
                print(f"Next tier: {tier_info['missing']}")
        return

    if args.check:
        services = (
            list(SERVICE_AUTH.keys())
            if args.check == "all"
            else [args.check]
        )

        results = {}
        for svc in services:
            if svc not in SERVICE_AUTH:
                results[svc] = {"available": False, "error": f"Unknown service: {svc}"}
                continue
            results[svc] = check_credentials(svc)

        if args.json:
            tier_info = detect_tier()
            output = {"status": "success", "tier": tier_info, "services": results}
            print(json.dumps(output, indent=2))
        else:
            tier_info = detect_tier()
            print(f"Backlink Tier: {tier_info['tier']} -- {tier_info['description']}")
            print()
            for svc, result in results.items():
                status = "OK" if result["available"] else "MISSING"
                print(f"  [{status}] {result.get('service', svc)}")
                if result.get("error"):
                    print(f"         {result['error']}")
                if result.get("verified_sites"):
                    print(f"         Verified sites: {', '.join(result['verified_sites'])}")
                if result.get("note"):
                    print(f"         Note: {result['note']}")
                if result.get("cached_domains") is not None:
                    print(f"         Cached domains: {result['cached_domains']}")
            print()
            if tier_info["missing"]:
                print(f"Tip: {tier_info['missing']}")
        return

    # Default: show tier
    tier_info = detect_tier()
    if args.json:
        print(json.dumps({"status": "success", "tier": tier_info}, indent=2))
    else:
        print(f"Backlink Tier: {tier_info['tier']} -- {tier_info['description']}")
        if tier_info["missing"]:
            print("Run --setup for configuration instructions.")


if __name__ == "__main__":
    main()
