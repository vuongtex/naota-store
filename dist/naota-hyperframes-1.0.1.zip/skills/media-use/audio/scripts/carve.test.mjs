import assert from "node:assert/strict";
import test from "node:test";
import { execFileSync, spawnSync } from "node:child_process";
import {
  chmodSync,
  closeSync,
  existsSync,
  fstatSync,
  linkSync,
  lstatSync,
  mkdirSync,
  mkdtempSync,
  openSync,
  readdirSync,
  readFileSync,
  realpathSync,
  rmSync,
  symlinkSync,
  writeFileSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { delimiter, dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  DEFAULT_STRENGTH,
  carveSources,
  groupSourceRefusal,
  mediaSource,
  parseArgs,
  readComposition,
  saveComposition,
} from "./carve.mjs";

const SCRIPTS_DIR = dirname(fileURLToPath(import.meta.url));

/** A voice as `detectTracks` yields it: an id plus its raw opening tag. */
function voice(id, group) {
  const attr = group === undefined ? "" : ` data-audio-group="${group}"`;
  return { id, tag: `<audio id="${id}"${attr} src="${id}.wav"></audio>` };
}

/** An audio member as `main` describes it for the source decision. */
function member(id, group, nameKind) {
  return { id, group, nameKind };
}

/** A bed as `mediaElements` yields it: `kind` is what decides group membership. */
function bed(id, group, kind = "audio") {
  const attr = group === undefined ? "" : ` data-audio-group="${group}"`;
  return { id, kind, tag: `<${kind} id="${id}"${attr} src="${id}.mp3"></${kind}>` };
}

async function inTempDir(run) {
  const dir = mkdtempSync(join(tmpdir(), "carve-test-"));
  try {
    return await run(dir);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
}

test("voices sharing one group carve against the group, not their ids", () => {
  // SKILL.md's invariant: "A carve against more than one clip id is wrong.
  // Group the clips and carve against the group." Naming the group lets
  // membership resolve at analysis time, so a voice added later is covered.
  const voices = [voice("vo1", "voiceover"), voice("vo2", "voiceover"), voice("vo3", "voiceover")];
  assert.deepEqual(carveSources(voices, undefined, []), ["voiceover"]);
});

test("a single grouped voice still records the group", () => {
  assert.deepEqual(carveSources([voice("vo1", "voiceover")], undefined, []), ["voiceover"]);
});

test("ungrouped voices keep their ids, so the lint rule can still say so", () => {
  // Not silently inventing a group: `audio_carve_ungrouped_sources` is the
  // right signal here, and it needs the ids to fire on.
  assert.deepEqual(carveSources([voice("vo1"), voice("vo2")], undefined, []), ["vo1", "vo2"]);
});

test("voices in DIFFERENT groups keep their ids", () => {
  // One carve cannot name two groups, and picking either would silently drop
  // the other's members from the analysis.
  const voices = [voice("vo1", "narration"), voice("vo2", "interview")];
  assert.deepEqual(carveSources(voices, undefined, []), ["vo1", "vo2"]);
});

test("a partially grouped set keeps its ids", () => {
  const voices = [voice("vo1", "voiceover"), voice("vo2")];
  assert.deepEqual(carveSources(voices, undefined, []), ["vo1", "vo2"]);
});

test("an empty group attribute is not a group", () => {
  assert.deepEqual(carveSources([voice("vo1", ""), voice("vo2", "")], undefined, []), [
    "vo1",
    "vo2",
  ]);
});

// The nine cases above pass `[]` explicitly because they predate the membership
// check and are about the bed and the group attributes alone. `members` is a
// required argument: with `[]` the `mixed` refusal cannot fire, so a default
// would let a call that forgot it return the group form and silently undo the
// widening fix — see the wiring test at the bottom of this file.

test("a bed inside the voices' group keeps clip ids, so it is never its own source", () => {
  // `resolveCarveSourceIds` expands a group to every CURRENT member, and it gets
  // no host element to exclude — so naming a group the bed belongs to puts the
  // bed in its own voice list on the next analysis, and it is carved against
  // itself. This run cannot see it (main sums the detected voices directly), so
  // the check has to happen here.
  const voices = [voice("vo1", "mix"), voice("vo2", "mix")];
  assert.deepEqual(carveSources(voices, bed("bgm", "mix"), []), ["vo1", "vo2"]);
});

test("a bed in a DIFFERENT group leaves the group form alone", () => {
  const voices = [voice("vo1", "voiceover"), voice("vo2", "voiceover")];
  assert.deepEqual(carveSources(voices, bed("bgm", "music"), []), ["voiceover"]);
});

test("an ungrouped bed leaves the group form alone", () => {
  assert.deepEqual(carveSources([voice("vo1", "voiceover")], bed("bgm"), []), ["voiceover"]);
});

test("a VIDEO bed is immune — group membership is audio-only", () => {
  // `data-audio-group` on a <video> is ignored by core, so expanding the group
  // can never pull this bed in and declining would be a false positive.
  const voices = [voice("vo1", "mix"), voice("vo2", "mix")];
  assert.deepEqual(carveSources(voices, bed("clip", "mix", "video"), []), ["mix"]);
});

test("an sfx member of the voices' group blocks the group form", () => {
  // The group resolves wider than the analysis: `resolveCarveSourceIds` expands
  // it to every current member and `resolveCarveVoices` keeps any audio with a
  // src, so an sfx clip sharing the voice group enters the sidechain on the next
  // analysis and ducks the bed under a whoosh. This run cannot see it — it sums
  // the voices `detectTracks` returned, which correctly excluded the sfx.
  const voices = [voice("vo1", "voiceover"), voice("vo2", "voiceover")];
  const members = [
    member("vo1", "voiceover", "voice"),
    member("vo2", "voiceover", "voice"),
    member("whoosh", "voiceover", "sfx"),
    member("bgm", "music", "music"),
  ];
  assert.deepEqual(carveSources(voices, bed("bgm", "music"), members), ["vo1", "vo2"]);
});

test("a music member of the voices' group blocks it too", () => {
  const voices = [voice("vo1", "voiceover")];
  const members = [member("vo1", "voiceover", "voice"), member("pad", "voiceover", "music")];
  assert.deepEqual(carveSources(voices, bed("bgm", "music"), members), ["vo1"]);
});

test("a voice member this run did NOT analyse keeps the group form", () => {
  // The designed case, and the one a membership check must not break: a voice
  // that does not overlap the bed is left out of the analysis on purpose, and
  // covering it on a later analysis without editing `sources` is the entire
  // reason SKILL.md says to name the group. Refusing here would collapse the
  // group form into clip ids for every ordinary narration sequence.
  const voices = [voice("vo1", "voiceover"), voice("vo2", "voiceover")];
  const members = [
    member("vo1", "voiceover", "voice"),
    member("vo2", "voiceover", "voice"),
    member("vo-outro", "voiceover", "voice"),
  ];
  assert.deepEqual(carveSources(voices, bed("bgm", "music"), members), ["voiceover"]);
});

test("an unclassifiable member keeps the group form", () => {
  // `unknown` is what `detectTracks` itself treats as a possible voice, so it is
  // not evidence of a non-voice member — loose in the safe direction, same as
  // detection.
  const voices = [voice("vo1", "voiceover")];
  const members = [member("vo1", "voiceover", "voice"), member("track7", "voiceover", "unknown")];
  assert.deepEqual(carveSources(voices, bed("bgm", "music"), members), ["voiceover"]);
});

test("an sfx member of a DIFFERENT group is irrelevant", () => {
  const voices = [voice("vo1", "voiceover")];
  const members = [member("vo1", "voiceover", "voice"), member("whoosh", "sfx", "sfx")];
  assert.deepEqual(carveSources(voices, bed("bgm", "music"), members), ["voiceover"]);
});

test("groupSourceRefusal names which member blocked the group, and why", () => {
  // The stderr note is built from this, so it has to carry the ids: "sources are
  // clip ids" plus `audio_carve_ungrouped_sources` reads as nonsense to an author
  // who did group their clips.
  const voices = [voice("vo1", "voiceover"), voice("vo2", "voiceover")];
  assert.deepEqual(
    groupSourceRefusal(voices, bed("bgm", "music"), [member("whoosh", "voiceover", "sfx")]),
    { group: "voiceover", reason: "mixed", ids: ["whoosh"] },
  );
  assert.deepEqual(groupSourceRefusal(voices, bed("bgm", "voiceover"), []), {
    group: "voiceover",
    reason: "bed",
    ids: ["bgm"],
  });
  assert.equal(groupSourceRefusal(voices, bed("bgm", "music"), []), null);
});

test("the CLI still runs when invoked through a symlinked path", () => {
  // argv[1] keeps the invoked spelling while import.meta.url is the realpath, so
  // a raw compare in the entry guard skips main() and the CLI exits 0 having
  // written nothing. macOS /tmp -> /private/tmp reaches this with no symlink of
  // one's own; so does any skill install placed behind a link.
  return inTempDir((dir) => {
    const link = join(dir, "scripts-link");
    symlinkSync(SCRIPTS_DIR, link, "junction");
    let status = 0;
    let stderr = "";
    try {
      execFileSync(process.execPath, [join(link, "carve.mjs")], { encoding: "utf-8" });
    } catch (error) {
      status = error.status;
      stderr = String(error.stderr);
    }
    // Reaching parseArgs is the proof main() ran at all: no args is an error, and
    // the broken guard's symptom is a silent exit 0 with no output.
    assert.equal(status, 1, `expected the usage error, got status ${status}`);
    assert.match(stderr, /--comp is required/);
  });
});

test("carve never loads @hyperframes/core from the composition's project", () => {
  // A received project is untrusted: a core planted in its node_modules must not run.
  return inTempDir(async (dir) => {
    const pkgDir = join(dir, "node_modules", "@hyperframes", "core");
    mkdirSync(pkgDir, { recursive: true });
    writeFileSync(join(dir, "package.json"), JSON.stringify({ name: "received-project" }));
    const planted =
      'import { writeFileSync } from "node:fs";\nwriteFileSync(new URL("./RAN", import.meta.url), "");\n';
    writeFileSync(join(pkgDir, "planted.mjs"), planted);
    writeFileSync(
      join(pkgDir, "package.json"),
      JSON.stringify({
        name: "@hyperframes/core",
        type: "module",
        exports: {
          "./package.json": "./package.json",
          "./audio-carve": "./planted.mjs",
          "./audio-fx": "./planted.mjs",
        },
      }),
    );
    writeFileSync(join(dir, "index.html"), "<html><body></body></html>");

    let stderr = "";
    try {
      execFileSync(
        process.execPath,
        [join(SCRIPTS_DIR, "carve.mjs"), "--comp", "index.html", "--dry-run"],
        {
          cwd: dir,
          stdio: "pipe",
        },
      );
    } catch (error) {
      stderr = String(error.stderr);
    }
    assert.equal(existsSync(join(pkgDir, "RAN")), false, "the project's @hyperframes/core ran");
    assert.match(
      stderr,
      /media in the composition/,
      "carve stopped before it read the composition",
    );
  });
});

test("the bundled core exports every function carve.mjs calls", async () => {
  const source = readFileSync(join(SCRIPTS_DIR, "carve.mjs"), "utf-8");
  const called = new Set([...source.matchAll(/carveApi\s*\.\s*(\w+)/g)].map((m) => m[1]));
  const bundle = await import("./lib/audio-carve.mjs");
  assert.ok(called.size > 0);
  assert.deepEqual(
    [...called].filter((name) => typeof bundle[name] !== "function"),
    [],
  );
});

test("members is required, so dropping it cannot silently restore the group form", () => {
  // The gap this closes: `main()` is the only code that BUILDS `members`, and no
  // test runs `main()` (the symlink test stops at the usage error, a real run
  // needs ffmpeg). With `members = []` defaulted, a refactor that dropped the
  // third argument would return the group form again with the whole suite green
  // — the same signature as the bug itself: first pass correct, persisted
  // attribute wrong, nothing red. Omitting it now throws instead.
  const voices = [voice("vo1", "voiceover"), voice("vo2", "voiceover")];
  assert.throws(() => carveSources(voices, bed("bgm", "music")), TypeError);
  assert.throws(() => groupSourceRefusal(voices, bed("bgm", "music")), TypeError);
});

test("the default strength is 0.8, and --strength still overrides it", () => {
  // 0.25 left the bed audibly fighting the voice on narrated builds; a carve at
  // the default has to already be a finished mix. Pinned so it cannot drift back
  // unnoticed — core pins its own DEFAULT_CARVE the same way.
  assert.equal(DEFAULT_STRENGTH, 0.8);
  assert.equal(parseArgs(["--comp", "x.html"]).strength, 0.8);
  assert.equal(parseArgs(["--comp", "x.html", "--strength", "0.25"]).strength, 0.25);
});

test("mediaSource accepts a regular file inside the composition's folder, by its real path", () =>
  inTempDir((dir) => {
    mkdirSync(join(dir, "assets"));
    writeFileSync(join(dir, "assets", "vo.wav"), "x");
    writeFileSync(join(dir, "bed.mp3"), "x");
    const real = realpathSync(dir);
    assert.equal(mediaSource(dir, "assets/vo.wav"), join(real, "assets", "vo.wav"));
    assert.equal(mediaSource(dir, "./bed.mp3"), join(real, "bed.mp3"));
    assert.equal(mediaSource(dir, "assets/../bed.mp3"), join(real, "bed.mp3"));
  }));

test("mediaSource refuses every name that leaves the folder, before opening it", () =>
  inTempDir((dir) => {
    const project = join(dir, "project");
    mkdirSync(project);
    const outside = join(dir, "secret.wav");
    writeFileSync(outside, "x");
    symlinkSync(outside, join(project, "linked.wav"));
    for (const src of [
      outside,
      "../secret.wav",
      "//attacker.example/share/x.mp3",
      "\\\\attacker.example\\share\\x.mp3",
      "C:secret.wav",
      "C:\\secret.wav",
      "file:///etc/hosts",
      "http://attacker.example/x.mp3",
      "linked.wav",
    ]) {
      assert.throws(() => mediaSource(project, src), /outside the composition's folder/, src);
    }
  }));

test("mediaSource refuses private files, folders, missing files and ffmpeg patterns", () =>
  inTempDir((dir) => {
    mkdirSync(join(dir, ".git"));
    mkdirSync(join(dir, "folder.wav"));
    for (const name of [".env", ".git/config", "id_rsa.wav", "take%d.png"]) {
      writeFileSync(join(dir, name), "x");
    }
    assert.throws(() => mediaSource(dir, ".env"), /private project file/);
    assert.throws(() => mediaSource(dir, ".git/config"), /private project file/);
    assert.throws(() => mediaSource(dir, "folder.wav"), /not a file in the project/);
    assert.throws(() => mediaSource(dir, "missing.wav"), /not a file in the project/);
    assert.throws(() => mediaSource(dir, "take%d.png"), /pattern of other files/);
  }));

/** A composition with a music bed and one narration track, both named by `src`. */
function writeComposition(dir, voiceSrc, bedSrc = "bed.wav") {
  writeFileSync(
    join(dir, "index.html"),
    `<audio id="music-bed" src="${bedSrc}" data-start="0"></audio>\n` +
      `<audio id="narration" src="${voiceSrc}" data-start="0"></audio>\n`,
  );
}

const runCarve = (cwd, env = process.env) =>
  spawnSync(process.execPath, [join(SCRIPTS_DIR, "carve.mjs"), "--comp", "index.html"], {
    cwd,
    env,
    encoding: "utf8",
  });

test(
  "a composition naming an outside file or a UNC host stops before any ffmpeg process starts",
  { skip: process.platform === "win32" && "the stand-in ffmpeg is a shell script" },
  () =>
    inTempDir((dir) => {
      const bin = join(dir, "bin");
      const ran = join(dir, "ffmpeg-ran");
      mkdirSync(bin);
      for (const tool of ["ffmpeg", "ffprobe"]) {
        writeFileSync(join(bin, tool), `#!/bin/sh\necho "$0 $*" >> "${ran}"\nexit 1\n`, {
          mode: 0o755,
        });
      }
      const project = join(dir, "project");
      mkdirSync(project);
      writeFileSync(join(project, "bed.wav"), "x");
      writeFileSync(join(dir, "secret.wav"), "x");
      const env = { ...process.env, PATH: `${bin}${delimiter}${process.env.PATH}` };
      for (const src of ["../secret.wav", "//attacker.example/share/x.mp3"]) {
        writeComposition(project, src);
        const before = readFileSync(join(project, "index.html"), "utf8");
        const run = runCarve(project, env);
        assert.equal(run.status, 1, run.stderr);
        assert.match(run.stderr, /outside the composition's folder/);
        assert.equal(existsSync(ran), false, `ffmpeg ran for ${src}`);
        assert.equal(readFileSync(join(project, "index.html"), "utf8"), before);
      }
    }),
);

const tone = (path, seconds = 2, frequency = 440) =>
  spawnSync(
    "ffmpeg",
    [
      "-y",
      "-loglevel",
      "error",
      "-f",
      "lavfi",
      "-i",
      `sine=frequency=${frequency}:duration=${seconds}`,
    ].concat([path]),
    { encoding: "utf8" },
  );

test("a playlist saved under a media name inside the project is refused and opens nothing it names", () =>
  inTempDir((dir) => {
    const project = join(dir, "project");
    mkdirSync(project);
    const outside = join(dir, "outside.ts");
    const made = spawnSync(
      "ffmpeg",
      ["-y", "-loglevel", "error", "-f", "lavfi", "-i", "sine=duration=1", "-c:a", "aac", outside],
      { encoding: "utf8" },
    );
    assert.equal(made.status, 0, made.stderr);
    assert.equal(tone(join(project, "bed.wav")).status, 0);
    writeFileSync(
      join(project, "narration.m3u8"),
      `#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXTINF:1,\n${outside}\n#EXT-X-ENDLIST\n`,
    );
    writeComposition(project, "narration.m3u8");
    const before = readFileSync(join(project, "index.html"), "utf8");
    const run = runCarve(project);
    assert.equal(run.status, 1, run.stderr);
    assert.match(run.stderr, /list that points at other files|not media in an accepted container/);
    assert.equal(readFileSync(join(project, "index.html"), "utf8"), before);
  }));

test("a composition whose media are files in its folder still carves", () =>
  inTempDir((dir) => {
    mkdirSync(join(dir, "assets"));
    assert.equal(tone(join(dir, "bed.wav"), 3, 220).status, 0);
    assert.equal(tone(join(dir, "assets", "narration.m4a"), 3, 1000).status, 0);
    writeComposition(dir, "assets/narration.m4a");
    const run = runCarve(dir);
    assert.equal(run.status, 0, run.stderr);
    assert.match(run.stdout, /wrote index.html/);
    assert.match(readFileSync(join(dir, "index.html"), "utf8"), /data-fx-chain=/);
  }));

// fails without the fix: main() read the composition with readFileSync, which follows a link at the name.
test("a link at the composition name stops the carve before anything is read or written", () =>
  inTempDir((dir) => {
    const project = join(dir, "project");
    mkdirSync(project);
    const outside = join(dir, "outside.html");
    const before = '<audio id="music-bed" src="bed.wav" data-start="0"></audio>\n';
    writeFileSync(outside, before);
    symlinkSync(outside, join(project, "index.html"));
    assert.throws(() => readComposition(join(project, "index.html")), /is a link/);
    const run = runCarve(project);
    assert.equal(run.status, 1);
    assert.match(run.stderr, /index\.html is a link or is reached through one/);
    assert.equal(readFileSync(outside, "utf-8"), before);
    assert.equal(lstatSync(join(project, "index.html")).isSymbolicLink(), true);
  }));

// fails without the fix: only the last name was looked at, so a linked folder led the read and the save outside.
test("a linked folder on the way to the composition stops the carve", () =>
  inTempDir((dir) => {
    const project = join(dir, "project");
    const outside = join(dir, "outside");
    mkdirSync(project);
    mkdirSync(outside);
    const before = '<audio id="music-bed" src="bed.wav" data-start="0"></audio>\n';
    writeFileSync(join(outside, "index.html"), before);
    symlinkSync(outside, join(project, "scenes"), "junction");
    const comp = join(project, "scenes", "index.html");
    assert.throws(() => readComposition(comp, project), /is reached through one/);
    const run = spawnSync(process.execPath, [join(SCRIPTS_DIR, "carve.mjs"), "--comp", comp], {
      cwd: project,
      encoding: "utf8",
    });
    assert.equal(run.status, 1);
    assert.match(run.stderr, /is a link or is reached through one/);
    assert.equal(readFileSync(join(outside, "index.html"), "utf-8"), before);
  }));

// fails without the fix: a folder whose name begins with two dots read as outside the project, so its link was followed.
test("a linked folder whose name begins with two dots stops the carve like any other", () =>
  inTempDir((dir) => {
    const project = join(dir, "project");
    const outside = join(dir, "outside");
    mkdirSync(project);
    mkdirSync(outside);
    const before = '<audio id="music-bed" src="bed.wav" data-start="0"></audio>\n';
    writeFileSync(join(outside, "index.html"), before);
    for (const name of ["..drafts", "...", "..a..b"]) {
      symlinkSync(outside, join(project, name), "junction");
      const comp = join(project, name, "index.html");
      assert.throws(() => readComposition(comp, project), /is reached through one/, name);
    }
    const run = spawnSync(
      process.execPath,
      [join(SCRIPTS_DIR, "carve.mjs"), "--comp", join("..drafts", "index.html")],
      { cwd: project, encoding: "utf8" },
    );
    assert.equal(run.status, 1);
    assert.match(run.stderr, /is a link or is reached through one/);
    assert.equal(readFileSync(join(outside, "index.html"), "utf-8"), before);
    // a plain folder of such a name is a project folder like any other
    mkdirSync(join(project, "..plain"));
    writeFileSync(join(project, "..plain", "index.html"), "<audio></audio>");
    assert.equal(
      readComposition(join(project, "..plain", "index.html"), project),
      "<audio></audio>",
    );
  }));

test("a composition that is a plain file reads, from its own folder or from outside the working folder", () =>
  inTempDir((dir) => {
    const comp = join(dir, "project", "index.html");
    mkdirSync(join(dir, "project"));
    writeFileSync(comp, "<audio></audio>");
    assert.equal(readComposition(comp, join(dir, "project")), "<audio></audio>");
    assert.equal(readComposition(comp, join(dir, "elsewhere")), "<audio></audio>");
    assert.throws(() => readComposition(join(dir, "project", "none.html"), dir), /does not exist/);
    assert.throws(() => readComposition(join(dir, "project"), dir), /not a regular file/);
  }));

// One handle for both, so the mode and the text are the same file's.
function modeAndText(path) {
  const file = openSync(path, "r");
  try {
    return [fstatSync(file).mode & 0o777, readFileSync(file, "utf-8")];
  } finally {
    closeSync(file);
  }
}

// Guards the save itself: a plain rename would put a default-mode file in place and overwrite a read-only one.
test(
  "saving keeps the composition's permissions and refuses one that may not be written",
  { skip: process.platform === "win32" && "POSIX permission bits" },
  () =>
    inTempDir((dir) => {
      const comp = join(dir, "index.html");
      writeFileSync(comp, "old");
      chmodSync(comp, 0o600);
      saveComposition(comp, "new");
      assert.deepEqual(modeAndText(comp), [0o600, "new"]);
      chmodSync(comp, 0o444);
      if (process.getuid?.() !== 0) {
        assert.throws(() => saveComposition(comp, "newer"), { code: "EACCES" });
        assert.deepEqual(modeAndText(comp), [0o444, "new"]);
      }
      assert.deepEqual(readdirSync(dir), ["index.html"]);
    }),
);

// fails without the fix: the new file held the composition under default permissions until a later chmod.
test(
  "while the new file holds the composition and is not yet in place, only its owner can read it",
  { skip: process.platform === "win32" && "POSIX permission bits" },
  () =>
    inTempDir((dir) => {
      const comp = join(dir, "index.html");
      for (const mode of [0o644, 0o600]) {
        writeFileSync(comp, "old");
        chmodSync(comp, mode);
        const seen = [];
        saveComposition(comp, "new", (temp) => seen.push(modeAndText(temp), modeAndText(comp)));
        assert.deepEqual(seen, [
          [0o600, "new"],
          [mode, "old"],
        ]);
        assert.deepEqual(modeAndText(comp), [mode, "new"]);
      }
      rmSync(comp);
      saveComposition(comp, "first");
      assert.deepEqual(modeAndText(comp), [0o666 & ~process.umask(), "first"]);
      assert.throws(
        () =>
          saveComposition(comp, "never", () => {
            throw new Error("stopped before the rename");
          }),
        /stopped before the rename/,
      );
      assert.equal(readFileSync(comp, "utf-8"), "first");
      assert.deepEqual(readdirSync(dir), ["index.html"]);
    }),
);

for (const [kind, plant] of [
  ["symbolic link", (target, at) => symlinkSync(target, at)],
  ["dangling symbolic link", (target, at) => symlinkSync(`${target}.missing`, at)],
  ["hard link", (target, at) => linkSync(target, at)],
]) {
  // fails without the fix: main() saved with writeFileSync, which writes into the target of a link at the name.
  test(`saving the composition replaces a ${kind} at its name, never the target`, () =>
    inTempDir((dir) => {
      const outside = join(dir, "outside.html");
      writeFileSync(outside, "outside");
      const comp = join(dir, "index.html");
      plant(outside, comp);
      saveComposition(comp, "<audio></audio>");
      assert.equal(readFileSync(outside, "utf-8"), "outside");
      assert.equal(readFileSync(comp, "utf-8"), "<audio></audio>");
      const entry = lstatSync(comp);
      assert.equal(entry.isFile(), true);
      assert.equal(entry.nlink, 1);
      assert.deepEqual(
        readdirSync(dir)
          .filter((name) => name !== "outside.html")
          .sort(),
        ["index.html"],
      );
    }));
}

// ESC, BEL, CR and LF from the composition must print only as visible escapes.
const CONTROLS = "\x1b]0;owned\x07\x1b[2J\r\nforged";
const hasControl = (text) =>
  [...text].some((ch) => {
    const code = ch.charCodeAt(0);
    return (code < 0x20 && ch !== "\n" && ch !== "\t") || (code >= 0x7f && code <= 0x9f);
  });
const assertShownSafely = (text) => {
  assert.equal(hasControl(text), false, JSON.stringify(text));
  assert.equal(/^forged/m.test(text), false, JSON.stringify(text));
  assert.match(text, /\\x1b\]0;owned\\x07\\x1b\[2J\\x0d\\x0aforged/);
};

test(
  "ids and group names with control characters print as escapes when the carve succeeds",
  { skip: process.platform === "win32" && "control characters in file names" },
  () =>
    inTempDir((dir) => {
      assert.equal(tone(join(dir, "bed.wav"), 3, 220).status, 0);
      assert.equal(tone(join(dir, "voice.wav"), 3, 1000).status, 0);
      const group = `grp${CONTROLS}`;
      writeFileSync(
        join(dir, "index.html"),
        `<audio id="music-bed${CONTROLS}" data-audio-group="${group}" src="bed.wav" data-start="0"></audio>\n` +
          `<audio id="narration${CONTROLS}" data-audio-group="${group}" src="voice.wav" data-start="0"></audio>\n`,
      );
      const run = runCarve(dir);
      assert.equal(run.status, 0, run.stderr);
      assertShownSafely(run.stdout);
      assertShownSafely(run.stderr);
      assert.match(run.stderr, /^note {3}bed /m);
      assert.match(readFileSync(join(dir, "index.html"), "utf8"), /data-fx-carve=/);
    }),
);

test(
  "ids and media names with control characters print as escapes when the carve refuses",
  { skip: process.platform === "win32" && "control characters in file names" },
  () =>
    inTempDir((dir) => {
      const refusals = [
        [
          `<audio id="music-a${CONTROLS}" src="a.wav"></audio>\n<audio id="music-b${CONTROLS}" src="b.wav"></audio>\n`,
          /several tracks look like music/,
        ],
        [`<audio id="music-bed${CONTROLS}" src="bed.wav"></audio>\n`, /no voice to make room for/],
      ];
      for (const [html, reason] of refusals) {
        writeFileSync(join(dir, "index.html"), html);
        const run = runCarve(dir);
        assert.equal(run.status, 1, run.stderr);
        assert.match(run.stderr, reason);
        assertShownSafely(run.stderr);
      }

      const named = spawnSync(
        process.execPath,
        [join(SCRIPTS_DIR, "carve.mjs"), "--comp", "index.html", "--bed", `gone${CONTROLS}`],
        { cwd: dir, encoding: "utf8" },
      );
      assert.equal(named.status, 1);
      assertShownSafely(named.stderr);

      assert.equal(tone(join(dir, "bed.wav"), 3, 220).status, 0);
      const media = `voice${CONTROLS}.wav`;
      writeFileSync(join(dir, media), "not media");
      writeComposition(dir, media);
      const decode = runCarve(dir);
      assert.equal(decode.status, 1);
      assert.match(decode.stderr, /could not decode/);
      assertShownSafely(decode.stderr);
    }),
);

test("a malformed JSON attribute on the bed stops the carve through its own message, writing nothing", () =>
  inTempDir((dir) => {
    assert.equal(tone(join(dir, "bed.wav"), 3, 220).status, 0);
    assert.equal(tone(join(dir, "voice.wav"), 3, 1000).status, 0);
    for (const [attr, reason] of [
      ['data-automation="{not json\x1b[2J"', /data-automation is not valid JSON/],
      ['data-automation="{&quot;lanes&quot;:7}"', /data-automation has no list of lanes/],
      ['data-fx-chain="[oops\x07"', /data-fx-chain is not a valid effect chain/],
    ]) {
      const html =
        `<audio id="music-bed" ${attr} src="bed.wav" data-start="0"></audio>\n` +
        `<audio id="narration" src="voice.wav" data-start="0"></audio>\n`;
      writeFileSync(join(dir, "index.html"), html);
      const run = runCarve(dir);
      assert.equal(run.status, 1, run.stderr);
      assert.match(run.stderr, reason);
      assert.doesNotMatch(run.stderr, /SyntaxError|\n\s+at /);
      assert.equal(hasControl(run.stderr), false);
      assert.equal(readFileSync(join(dir, "index.html"), "utf8"), html);
    }
  }));
